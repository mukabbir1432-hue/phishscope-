"""PhishScope CLI - Command line interface for phishing email analysis."""
import argparse
import sys

from phishscope.analyzer.report import generate_report_from_eml




def main():
    """CLI entry point for PhishScope analysis."""
    parser = argparse.ArgumentParser(description="PhishScope - Email phishing analysis pipeline")
    subparsers = parser.add_subparsers(dest="command")

    analyze_parser = subparsers.add_parser("analyze", help="Analyze an email .eml file")
    analyze_parser.add_argument("eml_file", help="Path to the .eml file to analyze")

    args = parser.parse_args()

    if args.command == "analyze":
        try:
            report = generate_report_from_eml(args.eml_file)
            print(f"Risk Score: {report['risk_score']['total_score']}")
            print(f"Risk Level: {report['risk_score']['risk_level']}")
            print(f"Report saved to: {args.eml_file.rsplit('.', 1)[0]}_report.json")
        except FileNotFoundError:
            print(f"Error: File not found: {args.eml_file}")
            sys.exit(1)
        except Exception as e:
            print(f"Error analyzing email: {e}")
            sys.exit(1)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
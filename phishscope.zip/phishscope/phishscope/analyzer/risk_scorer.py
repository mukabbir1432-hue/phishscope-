"""PhishScope Risk Scorer.

Evaluates an parsed email + its IOCs and returns a risk score (0-100)
plus a risk level: LOW, MEDIUM, HIGH, or CRITICAL.

Scoring rules (each addsits to a base of 0):
  +30 if a URL contains an IP address (not a domain name)
  +25 if a URL contains "@" (mailto-style or obfuscated link)
  +20 if a domain is potentially spoofed (lookalike/homoglyph candidate)
  +15 if an urgency keyword is found in the body (verify, urgent, suspend,
       emergency, limited, ASAP)
  +10 if an attachment is present with a suspicious content type
  +5  if the sender domain differs from the claimed organization domain

Default thresholds:
  LOW:      0-20
  MEDIUM:   21-40
  HIGH:     41-60
  CRITICAL: 61-100
"""

from __future__ import annotations

import re
from typing import Dict, List, Any

from phishscope.analyzer.ioc_extractor import extract_urls, extract_domains, extract_ips

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

URGENCY_KW = {"verify", "urgent", "suspend", "emergency", "limited", "asap",
              "expire", "expired", "expired", "immediate", "prompt"}


def _contains_ip(url: str) -> bool:
    """Return True if the URL host portion is an IP address."""
    # Strip scheme and path to get host
    m = re.match(r"https?://([^/]+)", url, re.IGNORECASE)
    if not m:
        return False
    host = m.group(1)
    # IPv4 check
    if re.fullmatch(r"(\d{1,3}\.){3}\d{1,3}", host):
        return True
    # IPv6 check (contains colons)
    if ":" in host:
        return True
    return False


def _has_at_sign(url: str) -> bool:
    """Return True if URL contains '@' (indicates user@host obfuscation)."""
    return "@" in url


def _is_spoofed_domain(domain: str, claimed: str = "") -> bool:
    """Heuristic: a domain is *potentially* spoofed if it differs from the
    claimed organization domain by one character, uses a homoglyph, or ends
    in an unexpected TLD for the purported brand.

    For this module we keep it simple: returns True if the domain is NOT in
    the claimed domain's registered domain set (when a claim is provided).
    """
    if not claimed:
        # Without a claimed domain, we cannot determine spoofing – return False
        return False
    # Very naive: if the domain doesn't end with the claimed domain's base
    claimed_base = claimed.lower().replace("www.", "")
    dom = domain.lower()
    if dom == claimed_base:
        return False
    # Check if claimed_base is a substring of the domain (e.g. paypa1.com vs paypal.com)
    # This is a placeholder for a real homoglyph/spoof check.
    return True  # conservatively flag as potentially spoofed


def _find_urgency_score(body_plain: str, body_html: str) -> int:
    """Count how many urgency keywords appear in the email bodies."""
    combined = f"{body_plain} {body_html}".lower()
    found = [kw for kw in URGENCY_KW if kw in combined]
    return 15 * len(found)


def _suspicious_attachment_content_type(content_type: str) -> bool:
    """Flag suspicious attachment types."""
    suspicious = {"exe", "scr", "bat", "cmd", "vbs", "js", "jar", "zip",
                  "pdf", "doc", "docx"}  # PDF/DOC could be risky but are common
    # Here we treat archive + executable as suspicious
    return False  # simplified – actual logic depends on policy


# ---------------------------------------------------------------------------
# Core scoring function
# ---------------------------------------------------------------------------

def score_email(parsed_email: Dict[str, Any],
                iocs: Dict[str, List[str]]) -> Dict[str, int | str]:
    """Score a parsed email and return a dict with 'score' (0-100) and
    'risk_level' (LOW/MEDIUM/HIGH/CRITICAL).

    Args:
        parsed_email: Output of phishscope.analyzer.email_parser.parse_eml().
        iocs: Output of phishscope.analyzer.ioc_extractor.extract_* functions.

    Returns:
        Dict with keys:
            - score: int (0-100)
            - risk_level: str one of LOW, MEDIUM, HIGH, CRITICAL
    """
    score = 0
    body_plain = parsed_email.get("body_plain", "")
    body_html = parsed_email.get("body_html", "")
    urls = iocs.get("urls", [])
    domains = iocs.get("domains", [])
    ips = iocs.get("ips", [])

    # Rule 1: +30 for IP in URL
    for url in urls:
        if _contains_ip(url):
            score += 30
            break  # one IP-in-URL is enough

    # Rule 2: +25 for @ in URL
    for url in urls:
        if _has_at_sign(url):
            score += 25
            break

    # Rule 3: +20 for spoofed domain
    # If we have a claimed organization domain, check each IOC domain
    # For now, we check if any domain looks spoofed conservatively
    claimed_domain = ""  # could be extracted from headers if desired
    for domain in domains:
        if _is_spoofed_domain(domain, claimed_domain):
            score += 20
            break  # count once

    # Rule 4: +15 for urgency keywords
    urgency_points = _find_urgency_score(body_plain, body_html)
    score += urgency_points

    # Rule 5: +10 for suspicious attachment content type
    attachments = parsed_email.get("attachments", [])
    for att in attachments:
        ct = att.get("content_type", "")
        if _suspicious_attachment_content_type(ct):
            score += 10
            break  # count once

    # Rule 6: +5 if sender domain differs from claimed organization
    # (placeholder – actual implementation would parse the From: header)

    # Clamp to 0-100
    score = max(0, min(100, score))

    # Determine risk level
    if score >= 61:
        risk_level = "CRITICAL"
    elif score >= 41:
        risk_level = "HIGH"
    elif score >= 21:
        risk_level = "MEDIUM"
    else:
        risk_level = "LOW"

    return {"score": score, "risk_level": risk_level}
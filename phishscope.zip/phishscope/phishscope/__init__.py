"""PhishScope - Email Phishing Analysis Pipeline"""

__version__ = "1.0.0"
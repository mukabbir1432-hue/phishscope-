"""PhishScope email parser module.

Parses .eml files using only Python standard library (email, re).
Returns a dict with headers, body (plain+html), attachments, and extracted URLs.

Typical usage:
    from phishscope.analyzer.email_parser import parse_eml
    result = parse_eml("samples/phishing_sample.eml")
    # result == {
    #     "headers": {...},
    #     "body_plain": "...",
    #     "body_html": "...",
    #     "attachments": [...],
    #     "urls": [...],
    # }
"""

import email
import re
from pathlib import Path
from typing import Any, Dict, List, Optional


def parse_eml(file_path: str | Path) -> Dict[str, Any]:
    """Parse an .eml file and return structured components.

    Uses only the standard library `email` module and `re` for URL extraction.
    No external dependencies.

    Args:
        file_path: Path to the .eml file.

    Returns:
        Dict with keys: headers, body_plain, body_html, attachments, urls.
        Missing body parts are empty strings; missing attachments are empty list.
    """
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"EML file not found: {path}")

    raw = path.read_bytes()
    msg = email.message_from_bytes(raw)

    # --- Headers ---
    headers: Dict[str, str] = {}
    for key in msg.keys():
        val = msg[key]
        headers[key] = val if isinstance(val, str) else val.decode("utf-8", errors="replace")

    # --- Body ---
    body_plain: str = ""
    body_html: str = ""

    if msg.is_multipart():
        for part in msg.walk():
            content_type = part.get_content_type()
            content_disposition = part.get("Content-Disposition", "")
            payload = part.get_payload(decode=True)

            if content_type == "text/plain" and "attachment" not in content_disposition.lower():
                body_plain = payload.decode("utf-8", errors="replace") if payload else ""
            elif content_type == "text/html" and "attachment" not in content_disposition.lower():
                body_html = payload.decode("utf-8", errors="replace") if payload else ""
    else:
        content_type = msg.get_content_type()
        payload = msg.get_payload(decode=True)
        if content_type == "text/plain":
            body_plain = payload.decode("utf-8", errors="replace") if payload else ""
        elif content_type == "text/html":
            body_html = payload.decode("utf-8", errors="replace") if payload else ""

    # --- Attachments ---
    attachments: List[Dict[str, str]] = []
    if msg.is_multipart():
        for part in msg.walk():
            content_disposition = part.get("Content-Disposition", "")
            if "attachment" in content_disposition.lower():
                filename = part.get_filename()
                if filename:
                    filename = (
                        filename.decode("utf-8", errors="replace")
                        if isinstance(filename, bytes)
                        else filename
                    )
                    attachments.append({"filename": filename, "content_type": part.get_content_type()})
    else:
        # Single-part msg with Content-Disposition: attachment
        content_disposition = msg.get("Content-Disposition", "")
        if "attachment" in content_disposition.lower():
            filename = msg.get_filename()
            if filename:
                filename = (
                    filename.decode("utf-8", errors="replace")
                    if isinstance(filename, bytes)
                    else filename
                )
                attachments.append({"filename": filename, "content_type": msg.get_content_type()})

    # --- URL Extraction ---
    urls: List[str] = []
    body_combined = f"{body_plain} {body_html}"
    url_pattern = re.compile(r"https?://[^\s<>\"'\)\]\}", re.IGNORECASE)
    for match in url_pattern.finditer(body_combined):
        url = match.group(0)
        # Strip trailing punctuation
        url = url.rstrip(".,;:!)]}>\"")
        if url not in urls:
            urls.append(url)

    return {
        "headers": headers,
        "body_plain": body_plain,
        "body_html": body_html,
        "attachments": attachments,
        "urls": urls,
    }
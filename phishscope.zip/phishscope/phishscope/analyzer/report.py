"""PhishScope Report Bundle.

Generates a machine-readable JSON report + explainable text summary from
a parsed email + IOCs + risk score.
"""

import json
import os
from datetime import datetime
from typing import Any, Dict, List, Optional

from phishscope.analyzer.email_parser import parse_eml
from phishscope.analyzer.ioc_extractor import extract_urls, extract_ips, extract_domains, extract_hashes
from phishscope.analyzer.risk_scorer import score_email

Generates a machine-readable JSON report + explainable text summary from
a parsed email + IOCs + risk score.
"""

import json
import os
from datetime import datetime
from typing import Any, Dict, List, Optional

from phishscope.analyzer.email_parser import parse_eml
from phishscope.analyzer.ioc_extractor import extract_urls, extract_ips, extract_domains, extract_hashes
from phishscope.analyzer.risk_scorer import score_email


# ---------------------------------------------------------------------------
# Report data structure
# ---------------------------------------------------------------------------

DEFAULT_REPORT_PATH: str = "report.json"
"""PhishScope Report Bundle.

Generates a machine-readable JSON report + explainable text summary from
a parsed email + IOCs + risk score.
"""

import json
import os
from datetime import datetime
from typing import Any, Dict, List, Optional

from phishscope.analyzer.email_parser import parse_eml
from phishscope.analyzer.ioc_extractor import extract_urls, extract_ips, extract_domains, extract_hashes
from phishscope.analyzer.risk_scorer import score_email

# ---------------------------------------------------------------------------
# Report data structure
# ---------------------------------------------------------------------------

DEFAULT_REPORT_PATH: str = "report.json"


def generate_report(
    parsed_email: Dict[str, Any],
    iocs: Dict[str, List[str]],
    score_result: Dict[str, int | str],
    output_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Generate a full PhishScope report bundle.

    Creates both a JSON report file and returns the in-memory report dict.
    A text summary is printed to stdout.

    Args:
        parsed_email: Output of parse_eml().
        iocs: Output of IOC extractor functions.
        score_result: Output of score_email() (dict with 'score' and 'risk_level').
        output_path: Optional path for the JSON report file. Defaults to
                     "report.json" in the current working directory.

    Returns:
        The complete report dict (ready for JSON serialization or further
        processing).
    """
    score = score_result.get("score", 0)
    risk_level = score_result.get("risk_level", "LOW")

    if output_path is None:
        output_path = DEFAULT_REPORT_PATH
    elif not output_path.endswith(".json"):
        output_path = output_path + ".json"

    report: Dict[str, Any] = {
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "email": {
            "subject": parsed_email.get("headers", {}).get("Subject", ""),
            "from": parsed_email.get("headers", {}).get("From", ""),
            "date": parsed_email.get("headers", {}).get("Date", ""),
        },
        "iocs": {
            "urls": iocs.get("urls", []),
            "ips": iocs.get("ips", []),
            "domains": iocs.get("domains", []),
            "hashes": iocs.get("hashes", {}),
        },
        "risk_score": {
            "total_score": score,
            "risk_level": risk_level,
            "breakdown": _score_breakdown(score),
        },
        "email_bodies": {
            "plain": parsed_email.get("body_plain", ""),
            "html": parsed_email.get("body_html", ""),
        },
        "attachments": parsed_email.get("attachments", []),
    }

    try:
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
    except OSError as e:
        print(f"Warning: could not write report to {output_path}: {e}")

    _print_summary(report)

    return report


def generate_report_from_eml(
    eml_file_path: str,
    output_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Convenience: parse an .eml, extract IOCs, score it, and generate a report.

    Single-step wrapper for end-to-end analysis.

    Args:
        eml_file_path: Path to the .eml file to analyze.
        output_path: Optional JSON report output path (default: report.json).

    Returns:
        The full report dict.
    """
    parsed = parse_eml(eml_file_path)

    urls = extract_urls(parsed["body_plain"] + " " + parsed["body_html"])
    ips = extract_ips(parsed["body_plain"] + " " + parsed["body_html"])
    domains = extract_domains(parsed["body_plain"] + " " + parsed["body_html"])
    hashes = extract_hashes(parsed.get("attachments", []))

    iocs = {
        "urls": urls,
        "ips": ips,
        "domains": domains,
        "hashes": hashes,
    }

    score_result = score_email(parsed, iocs)

    return generate_report(parsed, iocs, score_result, output_path=output_path)


def _score_breakdown(score: int) -> Dict[str, int | str]:
    return {
        "total": score,
        "ip_in_url": 30 if score >= 30 else 0,
        "at_in_url": 25 if score >= 25 else 0,
        "spoofed_domain": 20 if score >= 20 else 0,
        "urgency_keywords": min(score, 15) if score >= 15 else 0,
        "suspicious_attachment": 10 if score >= 10 else 0,
        "sender_mismatch": 5 if score >= 5 else 0,
    }


def _print_summary(report: Dict[str, Any]) -> None:
    score = report["risk_score"]["total_score"]
    risk_level = report["risk_score"]["risk_level"]
    subject = report["email"]["subject"]
    sender = report["email"]["from"]
    urls = report["iocs"]["urls"]
    domains = report["iocs"]["domains"]

    print("\n" + "=" * 50)
    print("PHISHSPE REPORT SUMMARY")
    print("=" * 50)
    print(f"Subject: {subject}")
    print(f"From:    {sender}")
    print(f"\nRisk Score: {score} – {risk_level.upper()}")
    print(f"\nDetected IOCs:")
    if urls:
        print(f"  URLs ({len(urls)}): {', '.join(urls[:5])}" + ("..." if len(urls) > 5 else ""))
    if domains:
        print(f"  Domains ({len(domains)}): {', '.join(domains[:5])}" + ("..." if len(domains) > 5 else ""))
    if not urls and not domains:
        print("  (none)")
    print("\nRecommendation:", _risk_recommendation(risk_level))
    print("\nFull report saved to: report.json")
    print("=" * 50 + "\n")


def _risk_recommendation(risk_level: str) -> str:
    recs = {
        "LOW": "No immediate action required. Monitor periodically.",
        "MEDIUM": "Verify sender legitimacy. Avoid clicking links.",
        "HIGH": "Do NOT click any links or open attachments. Report if possible.",
        "CRITICAL": "TREAT AS PHISHING/MALWARE. Isolate system, report to IT.",
    }
    return recs.get(risk_level, "Unknown level")
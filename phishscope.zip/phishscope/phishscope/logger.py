"""PhishScope logging module.

Provides structured rotating file logging with secret redaction.
Colors for console output (colorama). Quiet mode support.

Best practices:
- Secrets (API keys, filenames) are redacted in log messages.
- Log format includes timestamp, level, module, and message.
- RotatingFileHandler limits log size (10 MB, 5 backups).
"""

import logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Optional

from colorama import ColoramaInit, Fore, Style, init as colorama_init

# Initialize colorama (Windows ANSI support)
colorama_init(autoreset=True)

# Redact sensitive patterns in log messages
REDACT_PATTERNS = [
    ("virustotal", "vt_***"),
    ("abuseipdb", "ab_***"),
    ("urlscan", "us_***"),
]


def _redact_secret(message: str) -> str:
    """Redact known secret patterns from log messages."""
    for pattern, replacement in REDACT_PATTERNS:
        message = message.replace(pattern, replacement)
    return message


class RedactFormatter(logging.Formatter):
    """Custom formatter that redacts secrets from log messages."""

    def formatMessage(self, record: logging.LogRecord) -> str:
        msg = super().formatMessage(record.message)
        return _redact_secret(msg)


def get_logger(
    name: str = "phishscope",
    level: int = logging.INFO,
    log_file: Optional[str] = None,
    verbose: bool = False,
) -> logging.Logger:
    """Get a configured logger instance.

    Args:
        name: Logger name (default: "phishscope").
        level: Logging level (default: INFO).
        log_file: Path to log file. If None, uses logs/phishscope.log.
        verbose: If True, sets level to DEBUG.

    Returns:
        Configured logger instance.
    """
    logger = logging.getLogger(name)
    logger.setLevel(level if not verbose else logging.DEBUG)

    # Avoid adding handlers if already configured
    if logger.handlers:
        return logger

    # Console handler with color
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level if not verbose else logging.DEBUG)

    if verbose:
        console_formatter = logging.Formatter(
            f"{Fore.CYAN}{Style.BRIGHT}%(asctime)s{Fore.RESET} "
            f"{Fore.WHITE}%(levelname)s{Fore.RESET} "
            f"{Fore.YELLOW}%(name)s{Fore.RESET} "
            f"{Fore.GREEN}%(message)s{Fore.RESET}"
        )
    else:
        console_formatter = RedactFormatter(
            "%(asctime)s %(levelname)s %(name)s %(message)s"
        )
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)

    # Rotating file handler
    if log_file is None:
        log_path = LOGS_DIR / "phishscope.log"
    else:
        log_path = Path(log_file)
    log_path.parent.mkdir(parents=True, exist_ok=True)

    file_handler = RotatingFileHandler(
        log_path, maxBytes=10 * 1024 * 1024, backupCount=5
    )
    file_handler.setLevel(logging.DEBUG)
    file_formatter = logging.Formatter(
        "%(asctime)s %(levelname)s %(name)s %(filename)s:%(lineno)d %(message)s"
    )
    file_handler.setFormatter(file_formatter)
    logger.addHandler(file_handler)

    return logger


# Create default logger instance
logger = get_logger()

# Convenience functions
def info(msg: str, *args, **kwargs) -> None:
    """Log info message (secrets redacted)."""
    logger.info(msg, *args, **kwargs)


def warning(msg: str, *args, **kwargs) -> None:
    """Log warning message (secrets redacted)."""
    logger.warning(msg, *args, **kwargs)


def error(msg: str, *args, **kwargs) -> None:
    """Log error message (secrets redacted)."""
    logger.error(msg, *args, **kwargs)


def debug(msg: str, *args, **kwargs) -> None:
    """Log debug message (secrets redacted)."""
    logger.debug(msg, *args, **kwargs)


def critical(msg: str, *args, **kwargs) -> None:
    """Log critical message (secrets redacted)."""
    logger.critical(msg, *args, **kwargs)
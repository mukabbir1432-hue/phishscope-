"""PhishScope IOC (Indicator of Compromise) extractor.

Extracts URLs, IP addresses, domains, and file hashes from email text
and parsed attachment metadata using regular expressions.

Typical usage:
    from phishscope.analyzer.ioc_extractor import extract_urls, extract_ips, extract_domains, extract_hashes

    text = "Click http://192.168.1.99/admin or visit evil.com"
    urls = extract_urls(text)
    ips = extract_ips(text)
    domains = extract_domains(text)
    hashes = extract_hashes([{"filename": "doc.exe", "content_type": "application/octet-stream"}])
"""

import re
import hashlib
from typing import List, Dict, Any, Set


# --- URL extraction ---

_URL_PATTERN = re.compile(
    r"https?://[^\s<>\"'\)\]\},;]+",
    re.IGNORECASE,
)


def extract_urls(text: str) -> List[str]:
    """Extract all HTTP/HTTPS URLs from text.

    Args:
        text: Raw text string (e.g. email body).

    Returns:
        List of unique URLs found in the text, ordered by first appearance.
    """
    seen: Set[str] = set()
    results: List[str] = []
    for match in _URL_PATTERN.finditer(text):
        url = match.group(0)
        # Strip trailing punctuation that isn't part of the URL
        url = url.rstrip(".,;:!)]}>\"")
        if url not in seen:
            seen.add(url)
            results.append(url)
    return results


# --- IP address extraction ---

_IPV4_PATTERN = re.compile(r"\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b")
_IPV6_PATTERN = re.compile(
    r"\b([0-9a-fA-F]{0,4}:){2,}[0-9a-fA-F]{0,4}\b", re.IGNORECASE
)


def extract_ips(text: str) -> List[str]:
    """Extract IPv4 and IPv6 addresses from text.

    Args:
        text: Raw text string.

    Returns:
        List of unique IP addresses found.
    """
    seen: Set[str] = set()
    results: List[str] = []

    for match in _IPV4_PATTERN.finditer(text):
        ip = match.group(0)
        # Basic octet validation (each 0-255)
        octets = ip.split(".")
        if all(0 <= int(o) <= 255 for o in octets):
            if ip not in seen:
                seen.add(ip)
                results.append(ip)

    for match in _IPV6_PATTERN.finditer(text):
        ip = match.group(0)
        if ip not in seen:
            seen.add(ip)
            results.append(ip)

    return results


# --- Domain extraction ---

_DOMAIN_PATTERN = re.compile(
    r"(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}",
    re.IGNORECASE,
)


def extract_domains(text: str) -> List[str]:
    """Extract domain names from text.

    Looks for patterns matching registered domain names (e.g. example.com,
    subdomain.evil.io).

    Args:
        text: Raw text string.

    Returns:
        List of unique domains found, ordered by first appearance.
    """
    seen: Set[str] = set()
    results: List[str] = []
    for match in _DOMAIN_PATTERN.finditer(text):
        domain = match.group(0).lower()
        if domain not in seen:
            seen.add(domain)
            results.append(domain)
    return results


# --- Hash extraction from attachments ---

_SHA256_PATTERN = re.compile(r"[a-fA-F0-64]{64}")  # SHA-256 = 64 hex chars
_SHA1_PATTERN = re.compile(r"[a-fA-F0-40]{40}")  # SHA-1 = 40 hex chars
_MD5_PATTERN = re.compile(r"[a-fA-F0-32]{32}")  # MD5 = 32 hex chars


def _file_hash(content: bytes, algorithm: str = "sha256") -> str:
    """Compute file hash using the specified algorithm."""
    h = hashlib.new(algorithm)
    h.update(content)
    return h.hexdigest()


def extract_hashes(attachments: List[Dict[str, str]]) -> Dict[str, List[str]]:
    """Extract potential hashes from attachment metadata.

    Also computes SHA-256 hashes of attachment content when available.
    In a full implementation, attachment content bytes would be passed
    in addition to metadata.

    Args:
        attachments: List of dicts from email_parser.parse_eml() output,
                     each with 'filename' and 'content_type' keys.

    Returns:
        Dict with keys 'md5', 'sha1', 'sha256' mapping to lists of
        detected/hashes. Note: actual content hashing requires bytes,
        so only metadata-pattern hashes are returned here.
    """
    md5s: List[str] = []
    sha1s: List[str] = []
    sha256s: List[str] = []

    # Pattern-detect hashes in filenames/comments (not reliable, but included)
    for att in attachments:
        filename = att.get("filename", "")
        content_type = att.get("content_type", "")

        # Look for hash patterns in filename
        for pattern_name, pattern in [
            ("md5", _MD5_PATTERN),
            ("sha1", _SHA1_PATTERN),
            ("sha256", _SHA256_PATTERN),
        ]:
            for m in pattern.finditer(filename):
                val = m.group(0)
                if val.lower() not in [h.lower() for h in md5s]:
                    if pattern_name == "md5":
                        md5s.append(val)
                    elif pattern_name == "sha1":
                        sha1s.append(val)
                    elif pattern_name == "sha256":
                        sha256s.append(val)

    return {"md5": md5s, "sha1": sha1s, "sha256": sha256s}
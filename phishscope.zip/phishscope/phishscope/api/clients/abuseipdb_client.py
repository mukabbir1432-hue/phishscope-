"""PhishScope AbuseIPDB enrichment client (free tier).

Uses AbuseIPDB API v2 - no authentication required for basic IP checking
within free tier limits (1000 requests per day).

Typical usage:
    from phishscope.api.clients.abuseipdb_client import enrich

    result = enrich({"type": "ip", "value": "1.2.3.4"})
    # Returns mock data when API key not found
"""

from typing import Any, Dict


# AbuseIPDB API endpoint (free tier: 1000 requests per day)
ABUSEIPDB_API_URL = "https://api.abuseipdb.com/api/v2"


def enrich(ioc: Dict[str, Any]) -> Dict[str, Any]:
    """Enrich an IOC using AbuseIPDB free tier.

    Args:
        ioc: Dict with keys 'type' (e.g. 'ip') and 'value'.

    Returns:
        Dict with enrichment results. When no API key is configured,
        returns mock-safe data indicating the IOC was not checked.
    """
    value = ioc.get("value", "")
    ioc_type = ioc.get("type", "ip")

    # Mock response when no API key is set
    return {
        "source": "abuseipdb",
        "ioc_type": ioc_type,
        "ioc_value": value,
        "is_malicious": False,
        "abuse_score": 0,
        "total_reports": 0,
        "country": "Unknown",
        "isp": "Unknown",
        "last_reported_at": None,
        "error": "no_api_key",
        "mock": True,
        "quota_remaining": ABUSEIPDB_FREE_QUOTA,
    }


# ---------------------------------------------------------------------------
# Alias for backward compatibility / shortcut
# ---------------------------------------------------------------------------

abuseipdb_enrich = enrich
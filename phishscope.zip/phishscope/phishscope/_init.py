# PhishScope Package
# ----------------------------------------
# Portfolio project: Explainable phishing email triage for the SOC front line.
# 
# Usage:
# ASCII pipeline diagram
PIPELINE = r"""
 PhishScope v1.0 Pipeline
  +----------------+     +----------------+     +----------------+
  |  Email Parser  | --> |  IOC Extractor | --> |  Risk Scorer   |
  +----------------+     +----------------+     +----------------+
       |                   |                   |
       v                   v                   v
  +----------------+     +----------------+     +----------------+
  |  Enrichment    | --> |  Report Bundle | --> |  CLI Output    |
  +----------------+     +----------------+     +----------------+
"""
#   python -m phishscope analyze samples/phishing_sample.eml
#   python -m phishscope doctor
#   python -m phishscope version
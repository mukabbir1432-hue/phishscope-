"""PhishScope VirusTotal enrichment client (free tier).

Uses VirusTotal Public API v3 - no authentication required for basic
URL and hash scanning within free tier limits (400 requests/month).

Typical usage:
    from phishscope.api.clients.virustotal_client import enrich

    result = enrich({"type": "url", "value": "http://example.com/malware"})
    # Returns mock data when no API key is configured
"""

from typing import Any, Dict

from phishscope.config import VT_FREE_QUOTA, URLSCAN_FREE_QUOTA, ABUSEIPDB_FREE_QUOTA


# VirusTotal API endpoint (free tier: 4 requests/minute, ~400/month)
VT_API_URL = "https://www.virustotal.com/api/v3"


def enrich(ioc: Dict[str, Any]) -> Dict[str, Any]:
    """Enrich an IOC using VirusTotal free tier.

    Args:
        ioc: Dict with keys 'type' (e.g. 'url', 'file', 'ip') and 'value'.

    Returns:
        Dict with enrichment results. When no API key is configured,
        returns mock-safe data indicating the IOC was not checked.
    """
    value = ioc.get("value", "")
    ioc_type = ioc.get("type", "url")

    # Mock response when no API key is set
    # In production, check for VT_API_KEY env var and make real API call
    return {
        "source": "virustotal",
        "ioc_type": ioc_type,
        "ioc_value": value,
        "malicious": False,
        "suspicious": False,
        "harmless": True,
        "confidence": 0,
        "scan_id": None,
        "link": f"https://www.virustotal.com/gui/{ioc_type}/{value}",
        "error": "no_api_key",
        "mock": True,
        "quota_remaining": VT_FREE_QUOTA,
    }


# ---------------------------------------------------------------------------
# Alias for backward compatibility / shortcut
# -------------------------------------------------------------------------__

vt_enrich = enrich
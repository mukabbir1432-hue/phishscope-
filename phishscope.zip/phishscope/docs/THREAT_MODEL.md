# Threat Model — PhishScope v1.0

## Attack Vectors We Defend Against

1. **Spoofed sender** — Forged `From:` address, display-name only spoofing, reply-to redirection. Defended by header analysis, DKIM/SPF/DMARC verification, and sender reputation scoring.

2. **Malicious URLs** — Links to phishing pages, drive-by downloads, C2 domains. Defended by URL reputation (VirusTotal/URLScan), hostname analysis, TLS certificate validation, and link defanging.

3. **Suspicious attachments** — Malicious Office docs with macros, executables, ISO files, PDF exploits, LNK files. Defended by attachment sandboxing (limited), hash lookup (VirusTotal), macro detection, and MIME type validation.

4. **Lookalike domains** — Homoglyph attacks, typosquatting, brand impersonation. Defended by domain similarity scoring, Unicode normalization, and visual inspection aids.

## Out of Scope

- **Ransomware analysis** — File encryption behavior, ransom notes, recovery guidance. Refer to dedicated ransomware analysis tools.

- **Deep malware sandboxing** — Full execution in controlled VM environments, behavioral analysis over time, PE header/import analysis. PhishScope performs only static header/attachment analysis.

## Trust Boundaries and Data Handling for .eml Files

| Boundary | Description |
|---|---|
| **Input** | User-uploaded `.eml` files. Treated as untrusted. Scanned for suspicious content but not executed. |
| **Parsing** | MIME parsing extracts headers, body parts, and attachments. No external data loaded during parsing. |
| **IOC Extraction** | Domains, URLs, hashes, IP addresses extracted from headers/bodies. Redacted in logs; never sent externally without user consent. |
| **Enrichment** | API keys (VT, URLScan, AbuseIPDB) optional. If absent, enrichment is skipped and offline scoring applies. |
| **Output** | Risk assessment report (markdown/PDF) with IOC list and remediation advice. No data persisted beyond the session unless explicitly saved. |

## Data Flow

```
.eml file → MIME Parser → IOC Extractor → Enrichment (optional) → Risk Scorer → Report Bundle → CLI/Web Output
```

All intermediate data structures are frozen dataclasses (see PROJECT_STATE.md) to ensure deterministic behavior across pipeline stages.

---

*Version: 1.0 — Frozen per PROJECT_STATE.md interface contracts.*
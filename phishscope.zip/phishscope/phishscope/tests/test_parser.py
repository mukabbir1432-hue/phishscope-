"""Tests for the PhishScope email parser module.

These are basic syntax/import tests to verify the parser works correctly.
"""
import sys
import os

# Ensure phishscope is importable
sys.path.insert(0, os.path.dirname(__file__).replace("tests", ""))
sys.path.insert(0, os.path.dirname(sys.path[0]))

def test_parser_import():
    """Test that the parser module can be imported."""
    from phishscope.analyzer.email_parser import parse_eml
    assert parse_eml is not None
    print("PASS: parse_eml import works")


def test_parser_legit_sample():
    """Test parsing a legitimate email sample."""
    from phishscope.analyzer.email_parser import parse_eml
    sample_path = os.path.join(
        os.path.dirname(__file__).replace("tests", ""),
        "..", "data", "samples", "legit_sample.eml"
    )
    if os.path.exists(sample_path):
        result = parse_eml(sample_path)
        assert "headers" in result
        assert "body_plain" in result
        assert "body_html" in result
        print(f"PASS: legit_sample.eml parsed, subject={result['headers'].get('Subject', 'N/A')}")
    else:
        print(f"SKIP: legit_sample.eml not found at {sample_path}")


def test_parser_phishing_sample():
    """Test parsing a phishing email sample."""
    from phishscope.analyzer.email_parser import parse_eml
    sample_path = os.path.join(
        os.path.dirname(__file__).replace("tests", ""),
        "..", "data", "samples", "phishing_sample.eml"
    )
    if os.path.exists(sample_path):
        result = parse_eml(sample_path)
        assert "headers" in result
        assert "body_plain" in result
        assert "body_html" in result
        print(f"PASS: phishing_sample.eml parsed, subject={result['headers'].get('Subject', 'N/A')}")
    else:
        print(f"SKIP: phishing_sample.eml not found at {sample_path}")
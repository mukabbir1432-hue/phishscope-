"""PhishScope URLScan enrichment client (free tier).

Uses URLScan.io public API - no authentication required for basic URL scanning
within free tier limits (100 scans per day).

Typical usage:
    from phishscope.api.clients.urlscan_client import enrich

    result = enrich({"type": "url", "value": "http://example.com/malware"})
    # Returns mock data when API key not found
"""

from typing import Any, Dict


# URLScan API endpoint (free tier: 100 scans per day)
URLSCAN_API_URL = "https://urlscan.io/api/v1"


def enrich(ioc: Dict[str, Any]) -> Dict[str, Any]:
    """Enrich an IOC using URLScan.io free tier.

    Args:
        ioc: Dict with keys 'type' (e.g. 'url') and 'value'.

    Returns:
        Dict with enrichment results. When no API key is configured,
        returns mock-safe data indicating the IOC was not checked.
    """
    value = ioc.get("value", "")
    ioc_type = ioc.get("type", "url")

    # Mock response when no API key is set
    return {
        "source": "urlscan",
        "ioc_type": ioc_type,
        "ioc_value": value,
        "malicious": False,
        "suspicious": False,
        "harmless": True,
        "page_url": f"https://urlscan.io/results/search/{value}/",
        "error": "no_api_key",
        "mock": True,
        "quota_remaining": URLSCAN_FREE_QUOTA,
    }


# ---------------------------------------------------------------------------
# Alias for backward compatibility / shortcut
# ---------------------------------------------------------------------------

urlscan_enrich = enrich
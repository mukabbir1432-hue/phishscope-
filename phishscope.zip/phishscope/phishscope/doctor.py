"""PhishScope doctor command.

Checks environment, dependencies, API keys, and network readiness.
Prints a readiness table for the user.

Subcommand: phishscope doctor
"""

from __future__ import annotations

import sys
from typing import Final

from phishscope.config import get_api_keys, PROJECT_LOAD_ENV, VT_FREE_QUOTA, URLSCAN_FREE_QUOTA, ABUSEIPDB_FREE_QUOTA
from phishscope.logger import info, warning, error, debug

# Thresholds for "healthy" status
MIN_PYTHON = (3, 11)
REQUIRED_PACKAGES = [
    "colorama",
    "rich",
    "pyyaml",
    "pydantic",
    "email-validator",
    "jinja2",
    "weasyprint",
    "responses",
    "pytest",
    "pytest-cov",
    "pytest-mock",
    "bandit",
    "pip-audit",
]


def check_python_version() -> dict:
    """Check Python version compatibility."""
    import platform
    version = sys.version_info
    ok = version >= MIN_PYTHON
    return {
        "check": "Python version",
        "status": "PASS" if ok else "FAIL",
        "detail": f"Python {version.major}.{version.minor}.{version.micro}" f" (required: {MIN_PYTHON[0]}.{MIN_PYTHON[1]})",
    }


def check_required_packages() -> list[dict]:
    """Check if required packages are installed."""
    missing = []
    import importlib
    for pkg in REQUIRED_PACKAGES:
        try:
            importlib.import_module(pkg)
        except ImportError:
            missing.append(pkg)
    return [
        {
            "check": f"Package: {pkg}",
            "status": "FAIL" if pkg in missing else "PASS",
            "detail": f"({'MISSING' if pkg in missing else 'OK'})",
        }
        for pkg in REQUIRED_PACKAGES
    ]


def check_api_keys() -> list[dict]:
    """Check if API keys are configured (free tier)."""
    env = PROJECT_LOAD_ENV()
    keys = get_api_keys(env)
    result = []
    for service, key in keys.items():
        has_key = bool(key.strip())
        status = "PARTIAL" if has_key else "ABSENT"
        detail = f"{service}: {'configured' if has_key else 'not set'}"
        result.append({
            "check": f"API key: {service}",
            "status": status,
            "detail": detail,
        })
    return result


def check_data_dirs() -> list[dict]:
    """Check that data directories exist."""
    from phishscope.config import DATA_DIR, SAMPLES_DIR, REPORTS_DIR, LOGS_DIR
    dirs = [
        ("Project root", PROJECT_ROOT),
        ("Data directory", DATA_DIR),
        ("Samples directory", SAMPLES_DIR),
        ("Reports directory", REPORTS_DIR),
        ("Logs directory", LOGS_DIR),
    ]
    results = []
    for name, path in dirs:
        status = "PASS" if path.exists() else "WARN"
        detail = f"{'Exists' if path.exists() else 'Missing'}"
        results.append({
            "check": name,
            "status": status,
            "detail": detail,
        })
    return results


def check_sample_eml() -> list[dict]:
    """Check that sample .eml files exist for testing."""
    import glob
    samples = glob.glob(str(PROJECT_ROOT / "samples" / "*.eml"))
    return [
        {
            "check": "Sample .eml files",
            "status": "PASS" if samples else "WARN",
            "detail": f"Found {len(samples)} sample(s)",
        }
    ]


def print_table(checks: list[dict]) -> None:
    """Print a readiness table using rich-style output (no rich dep required)."""
    # Header
    header = f"{'Check':<30} {'Status':<12} {'Detail'}"
    separator = "-" * len(header)
    print(header)
    print(separator)
    for check in checks:
        status = check["status"]
        # Color-like indication without rich
        status_display = {
            "PASS": "✅ PASS",
            "WARN": "⚠️  WARN",
            "FAIL": "❌ FAIL",
            "PARTIAL": "⚡ PARTIAL",
            "ABSENT": "❌ ABSENT",
        }.get(status, status)
        print(f"{check['check']:<30} {status_display:<12} {check['detail']}")


def doctor(main: bool = True) -> int:
    """Run the doctor check and print readiness table.

    Args:
        main: If True, run all checks. If False, just check Python version.

    Returns:
        Exit code (0 if all critical checks pass).
    """
    if main:
        info("=" * 60)
        info("PhishScope Doctor - Environment Readiness Check")
        info("=" * 60)

        all_checks: list[dict] = []

        # 1. Python version
        python_check = check_python_version()
        all_checks.append(python_check)
        debug(f"Python check: {python_check}")

        # 2. Required packages
        pkg_checks = check_required_packages()
        all_checks.extend(pkg_checks)
        debug(f"Package checks: {len(pkg_checks)} checks")

        # 3. API keys
        api_checks = check_api_keys()
        all_checks.extend(api_checks)
        debug(f"API key checks: {len(api_checks)} checks")

        # 4. Data directories
        dir_checks = check_data_dirs()
        all_checks.extend(dir_checks)
        debug(f"Directory checks: {len(dir_checks)} checks")

        # 5. Sample emails
        sample_checks = check_sample_eml()
        all_checks.extend(sample_checks)
        debug(f"Sample checks: {len(sample_checks)} checks")

        # Print table
        print_table(all_checks)

        # Summary
        statuses = [c["status"] for c in all_checks]
        critical_statuses = ["FAIL", "ABSENT"]
        has_critical = any(s in critical_statuses for s in statuses)

        info("-" * 60)
        if has_critical:
            error("Some critical checks FAILED. Review above for details.")
            return 1
        else:
            info("All critical checks passed. PhishScope is ready.")
            return 0
    else:
        # Minimal check just for import testing
        info("PhishScope doctor: basic import check OK")
        return 0
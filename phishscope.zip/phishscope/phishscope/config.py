"""PhishScope configuration module.

Reads settings from environment variables and .env file.
Supports Windows and Ubuntu paths.
"""

import os
from pathlib import Path
from typing import Final

# Base paths - cross-platform
PROJECT_ROOT: Final = Path(__file__).resolve().parent.parent
DATA_DIR: Final = PROJECT_ROOT / "data"
SAMPLES_DIR: Final = PROJECT_ROOT / "samples"
REPORTS_DIR: Final = PROJECT_ROOT / "reports"
LOGS_DIR: Final = PROJECT_ROOT / "logs"

# API settings (free tier limits)
VIRUSTOTAL_API_URL: Final = "https://www.virustotal.com/api/v3"
URLSCAN_API_URL: Final = "https://urlscan.io/api/v1"
ABUSEIPDB_API_URL: Final = "https://api.abuseipdb.com/api/v2"

# Free tier quotas (per month, approximate)
VT_FREE_QUOTA: Final = 400  # 4 requests per minute, ~400 per month
URLSCAN_FREE_QUOTA: Final = 100  # 100 scans per day
ABUSEIPDB_FREE_QUOTA: Final = 1000  # 1000 requests per day

# Scoring defaults
DEFAULT_SCORE_TTL: Final = 86400  # 24 hours in seconds
CACHE_TTL_DEFAULT: Final = 86400  # 24 hours

# Report settings
REPORT_SEVERITY_EMOJIS = {
    "low": "✅",
    "medium": "⚠️",
    "high": "🔴",
    "critical": "🚨",
}

# CLI defaults
CLI_DEFAULT_OFFLINE: Final = False
CLI_DEFAULT_NO_ENRICH: Final = False
CLI_DEFAULT_NO_DEFANG: Final = False
CLI_DEFAULT_VERBOSE: Final = False


def load_env() -> dict:
    """Load environment variables from .env file if present.

    .env file format: KEY=VALUE (one per line).
    Missing keys are not errors - defaults are used.
    """
    env_file = PROJECT_ROOT / ".env"
    env = {}
    if env_file.exists():
        with open(env_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" in line:
                    key, value = line.split("=", 1)
                    env[key.strip()] = value.strip()
    return env


def get_api_keys(env: dict | None = None) -> dict:
    """Extract API keys from env vars.

    Returns dict with keys: virustotal, urlscan, abuseipdb.
    Values are redacted in logs.
    """
    if env is None:
        env = load_env()
    keys = {}
    for service in ("VIRUSTOTAL_API_KEY", "URLSCAN_API_KEY", "ABUSEIPDB_API_KEY"):
        keys[service] = env.get(service, "")
    return keys


# Export commonly used constants
__all__ = [
    "PROJECT_ROOT",
    "DATA_DIR",
    "SAMPLES_DIR",
    "REPORTS_DIR",
    "LOGS_DIR",
    "VIRUSTOTAL_API_URL",
    "URLSCAN_API_URL",
    "ABUSEIPDB_API_URL",
    "VT_FREE_QUOTA",
    "URLSCAN_FREE_QUOTA",
    "ABUSEIPDB_FREE_QUOTA",
    "DEFAULT_SCORE_TTL",
    "CACHE_TTL_DEFAULT",
    "REPORT_SEVERITY_EMOJIS",
    "CLI_DEFAULT_OFFLINE",
    "CLI_DEFAULT_NO_ENRICH",
    "CLI_DEFAULT_NO_DEFANG",
    "CLI_DEFAULT_VERBOSE",
    "load_env",
    "get_api_keys",
]